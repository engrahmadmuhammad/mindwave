// ============================================
// MINDWAVE DIGITAL - INTERACTIVE SCRIPTS
// ============================================

document.addEventListener('DOMContentLoaded', function() {

  // ========== MOBILE NAV TOGGLE ==========
  const navToggle = document.querySelector('.nav-toggle');
  const nav = document.querySelector('.nav');
  const navLinks = nav?.querySelectorAll('a');

  if (navToggle && nav) {
    navToggle.addEventListener('click', () => {
      nav.classList.toggle('open');
      navToggle.classList.toggle('open');
    });

    // Close nav when a link is clicked
    navLinks?.forEach(link => {
      link.addEventListener('click', () => {
        nav.classList.remove('open');
        navToggle.classList.remove('open');
      });
    });
  }

  // ========== SCROLL REVEAL ANIMATION ==========
  const revealElements = () => {
    const options = {
      threshold: 0.15,
      rootMargin: '0px 0px -100px 0px'
    };

    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('visible');
          observer.unobserve(entry.target);
        }
      });
    }, options);

    const targets = document.querySelectorAll(
      'section, .card, .service-card, .portfolio-item, .testimonial-card, .value-item'
    );

    targets.forEach(element => {
      element.classList.add('reveal');
      observer.observe(element);
    });
  };

  revealElements();

  // ========== HEADER SCROLL EFFECT ==========
  const header = document.querySelector('.header');
  if (header) {
    window.addEventListener('scroll', () => {
      const scrolled = window.scrollY > 50;
      header.style.boxShadow = scrolled 
        ? '0 5px 20px rgba(0, 0, 0, 0.1)' 
        : '0 2px 10px rgba(0, 0, 0, 0.05)';
    });
  }

  // ========== SMOOTH SCROLL ANCHOR LINKS ==========
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
      const href = this.getAttribute('href');
      if (href !== '#' && document.querySelector(href)) {
        e.preventDefault();
        document.querySelector(href).scrollIntoView({
          behavior: 'smooth',
          block: 'start'
        });
      }
    });
  });

  // ========== CONTACT FORM HANDLING ==========
  const contactForm = document.getElementById('contactForm');
  if (contactForm) {
    contactForm.addEventListener('submit', function(e) {
      e.preventDefault();
      
      // Get form data
      const formData = new FormData(this);
      const name = formData.get('name');
      const email = formData.get('email');
      const message = formData.get('message');

      // Validate
      if (!name || !email || !message) {
        alert('Please fill out all fields');
        return;
      }

      // Simple validation
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(email)) {
        alert('Please enter a valid email address');
        return;
      }

      // Success message
      alert(`Thank you, ${name}! We'll get back to you shortly at ${email}`);
      this.reset();
    });
  }

  // ========== PORTFOLIO FILTER (IF NEEDED) ==========
  const filterButtons = document.querySelectorAll('.filter-btn');
  const portfolioItems = document.querySelectorAll('.portfolio-item');

  filterButtons.forEach(button => {
    button.addEventListener('click', () => {
      const filter = button.dataset.filter;

      // Update active button
      filterButtons.forEach(btn => btn.classList.remove('active'));
      button.classList.add('active');

      // Filter items
      portfolioItems.forEach(item => {
        if (filter === 'all' || item.dataset.category === filter) {
          item.style.display = 'block';
          setTimeout(() => item.classList.add('visible'), 10);
        } else {
          item.style.display = 'none';
          item.classList.remove('visible');
        }
      });
    });
  });

  // ========== TESTIMONIAL CAROUSEL (OPTIONAL) ==========
  const testimonialCards = document.querySelectorAll('.testimonial-card');
  if (testimonialCards.length > 3) {
    let currentIndex = 0;
    
    const showTestimonial = (index) => {
      testimonialCards.forEach((card, i) => {
        card.style.display = i === index ? 'block' : 'none';
      });
    };

    // Show first testimonial
    showTestimonial(0);

    // Auto-rotate every 5 seconds (optional)
    setInterval(() => {
      currentIndex = (currentIndex + 1) % testimonialCards.length;
      showTestimonial(currentIndex);
    }, 5000);
  }

  // ========== BUTTON RIPPLE EFFECT ==========
  document.querySelectorAll('.btn').forEach(button => {
    button.addEventListener('click', function(e) {
      const ripple = document.createElement('span');
      const rect = this.getBoundingClientRect();
      const size = Math.max(rect.width, rect.height);
      const x = e.clientX - rect.left - size / 2;
      const y = e.clientY - rect.top - size / 2;

      ripple.style.width = ripple.style.height = size + 'px';
      ripple.style.left = x + 'px';
      ripple.style.top = y + 'px';
      ripple.classList.add('ripple');

      this.appendChild(ripple);

      setTimeout(() => ripple.remove(), 600);
    });
  });

  // ========== THEME TOGGLE (OPTIONAL) ==========
  const themeToggle = document.querySelector('.theme-toggle');
  if (themeToggle) {
    themeToggle.addEventListener('click', () => {
      document.body.classList.toggle('dark-theme');
      localStorage.setItem('theme', document.body.classList.contains('dark-theme') ? 'dark' : 'light');
    });

    // Load saved theme
    if (localStorage.getItem('theme') === 'dark') {
      document.body.classList.add('dark-theme');
    }
  }

  console.log('MindWave Digital Concept - Initialized Successfully ✨');
});