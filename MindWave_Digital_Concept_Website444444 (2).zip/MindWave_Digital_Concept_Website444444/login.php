<?php
// login.php - Handle authentication

session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $db_host = 'localhost';
    $db_user = 'root';
    $db_pass = '';
    $db_name = 'mindwave_db';

    $conn = new mysqli($db_host, $db_user, $db_pass, $db_name);

    if ($conn->connect_error) {
        $error = "Database connection failed";
    } else {
        $email = $conn->real_escape_string($_POST['email']);
        $password = $_POST['password'];

        $result = $conn->query("SELECT id, password FROM users WHERE email = '$email'");
        
        if ($result->num_rows > 0) {
            $user = $result->fetch_assoc();
            if (password_verify($password, $user['password'])) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['authenticated'] = true;
                header('Location: dashboard.html');
                exit();
            } else {
                $error = "Invalid password";
            }
        } else {
            $error = "User not found";
        }
        $conn->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login - Admin Portal</title>
  <link rel="stylesheet" href="style.css">
</head>
<body class="login-container">
  <div class="login-box">
    <h2>Sign In</h2>
    <?php if (isset($error)): ?>
      <div style="color: #d32f2f; margin-bottom: 15px; padding: 10px; background: #ffebee; border-radius: 4px;">
        <?= $error ?>
      </div>
    <?php endif; ?>
    <form action="login.php" method="POST">
      <div class="form-group">
        <label for="email">Email</label>
        <input type="email" id="email" name="email" required>
      </div>
      <div class="form-group">
        <label for="password">Password</label>
        <input type="password" id="password" name="password" required>
      </div>
      <div class="form-group" style="text-align:right;">
        <a href="#" style="font-size:0.9rem; color:var(--primary);">Forgot Password?</a>
      </div>
      <button type="submit">Login</button>
    </form>
  </div>
</body>
</html>
