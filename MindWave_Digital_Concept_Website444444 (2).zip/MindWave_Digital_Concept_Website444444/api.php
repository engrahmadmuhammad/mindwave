<?php
// api.php - Simple PHP backend for dashboard

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE');

// Database connection
$db_host = 'localhost';
$db_user = 'root';
$db_pass = '';
$db_name = 'mindwave_db';

$conn = new mysqli($db_host, $db_user, $db_pass, $db_name);

if ($conn->connect_error) {
    die(json_encode(['error' => 'Database connection failed']));
}

$action = $_GET['action'] ?? '';

// Routes
switch ($action) {
    case 'get_stats':
        get_stats();
        break;
    case 'get_users':
        get_users();
        break;
    case 'add_user':
        add_user();
        break;
    case 'delete_user':
        delete_user();
        break;
    default:
        echo json_encode(['error' => 'Invalid action']);
}

function get_stats() {
    global $conn;
    $stats = [
        'total_users' => $conn->query("SELECT COUNT(*) as count FROM users")->fetch_assoc()['count'] ?? 0,
        'active_sessions' => $conn->query("SELECT COUNT(*) as count FROM sessions WHERE active = 1")->fetch_assoc()['count'] ?? 0,
        'new_signups' => $conn->query("SELECT COUNT(*) as count FROM users WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)")->fetch_assoc()['count'] ?? 0,
        'api_calls' => rand(20000, 25000) // Placeholder
    ];
    echo json_encode($stats);
}

function get_users() {
    global $conn;
    $result = $conn->query("SELECT id, name, email, status FROM users LIMIT 10");
    $users = [];
    while ($row = $result->fetch_assoc()) {
        $users[] = $row;
    }
    echo json_encode($users);
}

function add_user() {
    global $conn;
    $data = json_decode(file_get_contents("php://input"), true);
    $name = $conn->real_escape_string($data['name']);
    $email = $conn->real_escape_string($data['email']);
    $status = $conn->real_escape_string($data['status'] ?? 'active');
    
    $conn->query("INSERT INTO users (name, email, status) VALUES ('$name', '$email', '$status')");
    echo json_encode(['success' => 'User added']);
}

function delete_user() {
    global $conn;
    $id = intval($_GET['id']);
    $conn->query("DELETE FROM users WHERE id = $id");
    echo json_encode(['success' => 'User deleted']);
}

$conn->close();
?>
