# 🎨 MindWave Digital - Visual Design System Guide

## Color Palette Reference

### Primary Colors
```
Dark Blue       #2B2D42
  Usage: Headings, main text, primary elements
  RGB: rgb(43, 45, 66)
  HSL: hsl(235, 21%, 21%)

Accent Red      #EF233C
  Usage: CTA buttons, highlights, hover states
  RGB: rgb(239, 35, 60)
  HSL: hsl(354, 92%, 54%)

Secondary Grey  #8D99AE
  Usage: Body text, subtle text, secondary info
  RGB: rgb(141, 153, 174)
  HSL: hsl(219, 22%, 62%)
```

### Neutral Colors
```
White           #FFFFFF
  Usage: Cards, backgrounds, text on dark

Black           #000000
  Usage: Contrast, shadows, dark text

Light Grey      #F8F9FA
  Usage: Section backgrounds, light areas

Border Grey     #E9ECEF
  Usage: Dividers, borders, subtle lines
```

---

## Typography System

### Font Stack
```css
Headings: 'Montserrat', -apple-system, BlinkMacSystemFont, sans-serif
Body:     'Open Sans', -apple-system, BlinkMacSystemFont, sans-serif
Icons:    Font Awesome 6.4.0
```

### Font Sizes
```
H1 (Hero):        2.8rem (desktop)  → 2rem (mobile)
H2 (Section):     2.2rem (desktop)  → 1.8rem (mobile)
H3 (Subheading):  1.5rem
H4 (Card title):  1.2rem
Body Text:        1rem (16px)
Small Text:       0.95rem
Extra Small:      0.8rem
```

### Font Weights
```
Light:    300 (rarely used)
Regular:  400 (body text)
Medium:   500 (emphasis)
Semibold: 600 (buttons, labels)
Bold:     700 (headings)
```

### Line Heights
```
Headings:     1.2 (tight)
Subheadings:  1.4 (medium)
Body Text:    1.6 (spacious)
Captions:     1.4
```

---

## Button System

### Button States

#### Primary Button (Red)
```css
Default:  #EF233C (red)
Hover:    #d41930 (darker red) + transform: translateY(-2px)
Active:   #b81527 (even darker)
Disabled: #ccc

Box Shadow:
  Default:  0 8px 20px rgba(239, 35, 60, 0.3)
  Hover:    0 14px 36px rgba(239, 35, 60, 0.18)
```

#### Secondary Button (Outline)
```css
Default:  transparent background, #EF233C border
Hover:    #EF233C background, white text
Active:   darker red background

Border: 2px solid #EF233C
```

#### Light Button (White)
```css
Default:  white background, #EF233C text
Hover:    #F8F9FA background
```

### Button Sizes
```
Small:    padding: 8px 14px,   font-size: 0.9rem
Regular:  padding: 10px 20px,  font-size: 0.95rem
Large:    padding: 14px 32px,  font-size: 1rem
```

---

## Spacing Scale

```
xs:  4px
sm:  8px
md:  12px
lg:  16px
xl:  20px
2xl: 30px
3xl: 40px
4xl: 50px
5xl: 60px
6xl: 80px
```

### Common Spacing
```
Section Padding:      80px (desktop), 60px (mobile)
Card Padding:         25-40px
Element Gap:          20-30px
Component Margin:     20px
Line Height:          1.4-1.8
```

---

## Border Radius

```
Small:    4px   (subtle curves)
Medium:   6px   (cards, buttons - default)
Large:    8px   (prominent elements)
Circle:   50%   (avatars, badges)
```

---

## Shadow System

```
Light:    0 2px 10px rgba(0, 0, 0, 0.05)
Medium:   0 5px 20px rgba(0, 0, 0, 0.08)
Dark:     0 8px 30px rgba(0, 0, 0, 0.1)
Heavy:    0 20px 44px rgba(0, 0, 0, 0.12)

Accent Shadows:
Light:    0 8px 20px rgba(239, 35, 60, 0.3)
Medium:   0 15px 40px rgba(239, 35, 60, 0.15)
```

---

## Breakpoints

```
Mobile Small:  < 480px
Mobile:        480px - 767px
Tablet:        768px - 1199px
Desktop:       1200px+

Usage:
@media (max-width: 768px) { ... }
@media (max-width: 480px) { ... }
```

---

## Card Components

### Service Card
```
Background:    white
Border:        top 4px solid transparent
Shadow:        medium
Padding:       40px 30px
Hover Effects: 
  - translate Y -10px
  - border-top color change to #EF233C
  - shadow increase
```

### Portfolio Item
```
Position:      relative
Border-radius: 12px
Aspect Ratio:  4/3
Overlay:       rgba(43, 45, 66, 0.85)
Hover:         image scale 1.05, overlay opacity 1
```

### Testimonial Card
```
Background:    white
Padding:       35px
Border-radius: 12px
Shadow:        medium
Hover:         shadow increase, translate Y -5px
```

### Team Member Card
```
Border-radius: 12px
Overflow:      hidden
Image Height:  280px
Info Padding:  25px
Social Links:  4 small icons (32px)
```

---

## Animation System

### Timing
```
Fast:     0.2s (quick feedback)
Normal:   0.3s (standard)
Slow:     0.7s (entrance animations)
Extra:    0.8-0.9s (hero animations)
```

### Easing
```
ease:         cubic-bezier(0.25, 0.46, 0.45, 0.94)
ease-in:      slower start
ease-out:     slower end
ease-in-out:  slower at both ends
linear:       constant speed
```

### Common Animations
```
Fade In:      opacity: 0 → 1
Slide Up:     translateY(30px) → 0
Slide Down:   translateY(-30px) → 0
Scale Up:     scale(1) → 1.05
Scale Down:   scale(1.05) → 1
```

### Hero Section Animations
```
Title:        slideInDown 0.8s ease-out
Subtitle:     slideInUp 0.8s ease-out 0.2s both
CTA Button:   slideInUp 0.8s ease-out 0.4s both
```

---

## Responsive Behavior

### Hero Section
```
Desktop:  120px padding, min-height: 70vh
Tablet:   100px padding, min-height: 60vh
Mobile:   80px padding, min-height: 50vh
```

### Grid Layouts
```
3 Columns:  repeat(auto-fit, minmax(300px, 1fr))
             → 2 cols on tablet, 1 col on mobile

4 Columns:  repeat(auto-fit, minmax(250px, 1fr))
             → 2 cols on tablet, 1 col on mobile
```

### Text Sizing
```
H1: clamp(2rem, 5vw, 3.5rem)
    → scales between 2rem and 3.5rem

H2: clamp(2rem, 4vw, 2.8rem)
    → responsive scaling
```

---

## Interactive Elements

### Hover Effects
```
Cards:    transform: translateY(-8px to -10px)
Buttons:  transform: translateY(-2px) + shadow increase
Links:    underline appears or color changes
Icons:    color change or slight rotate
```

### Focus States
```
Buttons:  outline: 2px solid #EF233C
Links:    outline: 2px solid #EF233C
Inputs:   border-color: #EF233C + shadow
```

### Active States
```
Buttons:  darker color + no transform
Links:    underline visible
```

---

## Footer Design

### Layout
```
Grid:      4 columns on desktop
           2 columns on tablet
           1 column on mobile

Background: #2B2D42 (primary dark)
Text:       white or rgba(255, 255, 255, 0.8)
Links:      hover to #EF233C
```

### Colors in Footer
```
Section Titles:  #EF233C (accent)
Body Text:       rgba(255, 255, 255, 0.8)
Links:           inherit, hover to #EF233C
Border:          rgba(255, 255, 255, 0.2)
```

---

## Form Design

### Input Fields
```
Padding:        12px 15px
Border:         2px solid #E9ECEF
Border Radius:  6px
Font Family:    'Open Sans'
Font Size:      0.95rem

Focus State:
  Border Color: #EF233C
  Box Shadow:   0 0 0 3px rgba(239, 35, 60, 0.1)
```

### Labels
```
Font Weight:    600
Color:          #2B2D42
Font Size:      0.95rem
Margin Bottom:  8px
```

### Buttons (in forms)
```
Width:          100% or auto
Padding:        14px 32px
Background:     #EF233C
Color:          white
Font Weight:    600
Cursor:         pointer
Transition:     all 0.3s ease
```

---

## Navigation Styles

### Header
```
Position:       sticky
Background:     white
Border Bottom:  1px solid #E9ECEF
Shadow:         0 2px 10px rgba(0, 0, 0, 0.05)
Padding:        15px 0
```

### Nav Links
```
Color:          #2B2D42
Font Weight:    500
Font Size:      0.95rem
Transition:     color 0.3s ease

Hover:
  Color:        #EF233C
  Underline:    2px solid #EF233C (from 0 width)
```

### Mobile Nav
```
Position:       fixed
Left:           -100% (closed) → 0 (open)
Top:            60px
Width:          100%
Background:     white
Shadow:         0 10px 27px rgba(0, 0, 0, 0.05)
Flex:           column
Gap:            15px
Padding:        20px 0
Transition:     0.3s
```

---

## Accessibility Colors

### Contrast Ratios (WCAG AA)
```
Text on Primary (#2B2D42):     Needs light color (7.5:1)
Text on Accent (#EF233C):      White text (4.5:1+)
Text on Light Grey (#F8F9FA):  Dark text (7:1+)
```

### Color Blindness
```
Red accent (#EF233C):   Works for red-green
Text always has:        Size + weight contrast, not just color
Borders/Icons:          Color + shape differentiation
```

---

## Print Styles (Optional)

```css
@media print {
  header, footer, .nav: display: none
  body: background: white
  colors: use print-safe colors
  buttons: display: none or style differently
}
```

---

## Dark Mode (Future Enhancement)

If implementing dark mode:
```
Primary Text:  #FFFFFF (currently #2B2D42)
Secondary:     #8D99AE (lighter)
Background:    #1a1c2e (currently white)
Cards:         #2B2D42 (darker background)
Accent:        #FF5555 (slightly lighter red)
```

---

## Design Tokens Summary

| Token | Value | Usage |
|-------|-------|-------|
| `--primary` | #2B2D42 | Main text, headings |
| `--accent` | #EF233C | Buttons, highlights |
| `--secondary` | #8D99AE | Secondary text |
| `--white` | #FFFFFF | Light backgrounds |
| `--light-bg` | #F8F9FA | Section backgrounds |
| `--border` | #E9ECEF | Dividers, borders |
| `--transition` | all 0.3s ease | Default transition |

---

## Quick Copy-Paste Colors

```html
<!-- Primary Text -->
color: var(--primary);        /* #2B2D42 */

<!-- Accent Button -->
background: var(--accent);    /* #EF233C */

<!-- Secondary Text -->
color: var(--secondary);      /* #8D99AE */

<!-- Light Section -->
background: var(--light-bg);  /* #F8F9FA */

<!-- Border -->
border: 1px solid var(--border);  /* #E9ECEF */
```

---

## Design Best Practices Used

✅ **Consistent Spacing** - All spacing follows 4px grid  
✅ **Color Harmony** - Complementary color scheme  
✅ **Typography Hierarchy** - Clear visual hierarchy  
✅ **Accessibility** - High contrast ratios  
✅ **Responsive** - Works on all devices  
✅ **Performance** - Smooth animations  
✅ **Modern** - Current design trends  
✅ **Professional** - Corporate aesthetic  

---

**This design system ensures consistency across all pages and is easy to maintain and update!** 🎨