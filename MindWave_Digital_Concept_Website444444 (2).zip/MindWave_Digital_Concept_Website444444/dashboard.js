// dashboard.js - Fetch data from PHP backend

document.addEventListener('DOMContentLoaded', function() {
    loadStats();
    loadUsers();
});

function loadStats() {
    fetch('api.php?action=get_stats')
        .then(response => response.json())
        .then(data => {
            document.querySelector('[data-stat="total_users"]').textContent = data.total_users;
            document.querySelector('[data-stat="active_sessions"]').textContent = data.active_sessions;
            document.querySelector('[data-stat="new_signups"]').textContent = data.new_signups;
            document.querySelector('[data-stat="api_calls"]').textContent = data.api_calls;
        })
        .catch(error => console.error('Error loading stats:', error));
}

function loadUsers() {
    fetch('api.php?action=get_users')
        .then(response => response.json())
        .then(data => {
            const tbody = document.querySelector('.table-preview tbody');
            tbody.innerHTML = '';
            data.forEach(user => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${user.id}</td>
                    <td>${user.name}</td>
                    <td>${user.email}</td>
                    <td>${user.status}</td>
                    <td><button onclick="editUser(${user.id})">Edit</button></td>
                `;
                tbody.appendChild(row);
            });
        })
        .catch(error => console.error('Error loading users:', error));
}

function toggleSidebar() {
    document.querySelector('.sidebar').classList.toggle('collapsed');
    document.querySelector('.topbar').classList.toggle('collapsed');
    document.querySelector('.admin-content').classList.toggle('collapsed');
}

function editUser(id) {
    alert('Edit user ' + id);
    // Add your edit logic here
}
