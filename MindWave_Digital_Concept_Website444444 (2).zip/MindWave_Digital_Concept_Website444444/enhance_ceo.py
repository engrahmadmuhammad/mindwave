"""
CEO Portrait Enhancement Script
Enhances CEO.jpg to studio-quality professional portrait:
- Removes background
- Applies skin-smooth bilateral filter
- Sharpens with unsharp mask
- Adjusts color, contrast, and saturation
- Adds subtle vignette for studio feel
- Composites clean modern background
"""

import sys
from io import BytesIO
from PIL import Image, ImageEnhance, ImageFilter, ImageOps
import numpy as np
import cv2

def pil_to_cv(img):
    """Convert PIL Image to OpenCV format (BGR)."""
    return cv2.cvtColor(np.array(img), cv2.COLOR_RGB2BGR)

def cv_to_pil(cv_img):
    """Convert OpenCV image (BGR) to PIL Image (RGB)."""
    return Image.fromarray(cv2.cvtColor(cv_img, cv2.COLOR_BGR2RGB))

def unsharp_mask(cv_img, amount=1.2, radius=3):
    """Apply unsharp mask for gentle sharpening."""
    blurred = cv2.GaussianBlur(cv_img, (0, 0), radius)
    return cv2.addWeighted(cv_img, 1.0 + amount, blurred, -amount, 0)

def gentle_skin_smooth(cv_img, diameter=9, sigma_color=75, sigma_space=75):
    """Bilateral filter for skin-preserving smoothing."""
    return cv2.bilateralFilter(cv_img, diameter, sigma_color, sigma_space)

def make_studio_bg(size, color1=(245, 247, 250), color2=(230, 235, 245)):
    """Create a subtle gradient studio background."""
    w, h = size
    bg = Image.new("RGB", size, color1)
    grad = Image.new("L", (1, h))
    for y in range(h):
        grad.putpixel((0, y), int(255 * (y / (h - 1))))
    grad = grad.resize((w, h))
    overlay = Image.new("RGB", (w, h), color2)
    bg.paste(overlay, (0, 0), grad)
    return bg

def apply_vignette(pil_img):
    """Apply subtle vignette for studio-like portrait feel."""
    w, h = pil_img.size
    vignette = Image.new("L", (w, h), 0)
    
    for y in range(h):
        for x in range(w):
            dx = (x - w / 2) / (w / 2)
            dy = (y - h / 2) / (h / 2)
            d = dx * dx + dy * dy
            val = int(255 * (1 - min(1, d * 0.5)))
            vignette.putpixel((x, y), val)
    
    vignette = vignette.filter(ImageFilter.GaussianBlur(radius=int(min(w, h) * 0.08)))
    pil_img.putalpha(255)
    black = Image.new("RGBA", pil_img.size, (0, 0, 0, 0))
    result = Image.composite(pil_img, black, ImageOps.invert(vignette).convert("L"))
    return result.convert("RGB")

def enhance_portrait(in_path, out_path):
    """Main enhancement pipeline."""
    print(f"Loading {in_path}...")
    
    # Try to remove background with rembg; fallback to manual processing
    try:
        from rembg import remove
        print("Removing background with rembg...")
        with open(in_path, "rb") as f:
            input_bytes = f.read()
        result_bytes = remove(input_bytes)
        fg = Image.open(BytesIO(result_bytes)).convert("RGBA")
        
        # Auto-crop to subject
        bbox = fg.getbbox()
        if bbox:
            fg = fg.crop(bbox)
    except ImportError:
        print("rembg not available; using image as-is for enhancement...")
        fg = Image.open(in_path).convert("RGBA")
    
    # Ensure RGBA for compositing
    if fg.mode != "RGBA":
        fg = fg.convert("RGBA")
    
    # Create and composite studio background
    print("Creating studio background...")
    bg = make_studio_bg(fg.size, (245, 247, 250), (230, 235, 245))
    bg = bg.convert("RGBA")
    composed = Image.alpha_composite(bg, fg).convert("RGB")
    
    # Convert to OpenCV for enhancement
    print("Applying skin smoothing...")
    cv = pil_to_cv(composed)
    smooth = gentle_skin_smooth(cv, diameter=9, sigma_color=60, sigma_space=60)
    
    # Sharpen
    print("Sharpening...")
    sharp = unsharp_mask(smooth, amount=0.9, radius=1.5)
    final = cv_to_pil(sharp)
    
    # Color and contrast adjustments
    print("Adjusting colors and contrast...")
    final = ImageEnhance.Color(final).enhance(1.05)
    final = ImageEnhance.Contrast(final).enhance(1.08)
    final = ImageEnhance.Sharpness(final).enhance(1.05)
    final = ImageEnhance.Brightness(final).enhance(1.02)
    
    # Apply vignette
    print("Adding vignette...")
    final = apply_vignette(final)
    
    # Save
    print(f"Saving enhanced image to {out_path}...")
    final.save(out_path, quality=95)
    print(f"✓ Enhancement complete: {out_path}")

if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Usage: python enhance_ceo.py input.jpg output.jpg")
        sys.exit(1)
    enhance_portrait(sys.argv[1], sys.argv[2])
